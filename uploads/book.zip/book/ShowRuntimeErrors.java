// ShowRuntimeErrors.java: Program contains runtime errors
public class ShowRuntimeErrors {
  public static void main(String[] args) {
    int i = 1 / 0;
  }
}
