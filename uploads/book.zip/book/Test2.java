import java.util.Scanner;

public class Test2 {
  public static void main(String[] args) {
    String s = String.format("%5.2f", 45.556); 
    System.out.println(s);
  }
}
