public class Test1 {
  public static void main(String[] args) {
    System.out.println(Test.getGrade(45));
    Test.printGrade(3434);
    System.out.println(Math.pow(4, 5));
    
  }
}
