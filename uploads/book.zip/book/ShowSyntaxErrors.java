// ShowSyntaxErrors.java: The program contains syntax errors
public class ShowSyntaxErrors {
  public static void main(String[] args) {
//    i = 30;
//    System.out.println(i + 4);
  }
}
